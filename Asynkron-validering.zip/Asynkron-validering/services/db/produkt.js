const db = require('../../config/database').connect();

module.exports = {

    getCount: function (name) {

        return new Promise((resolve, reject) => {
            var sql = `
                    SELECT COUNT(*) AS antal
                    FROM produkt
                    WHERE produkt.navn = ?
                `;
            db.query(sql, [name], function (err, result) {
                if (err) reject(err)

                resolve(result);
            });

        })
    },

    insertProduct: function (id, navn, pris, kategori) {
        return new Promise((resolve, reject) => {
            var sql = `
                    insert into produkt set 
                    id='${id}',
                    navn='${navn}',
                    pris='${pris}',
                    fk_kategori='${kategori}'
                    `;
            console.log(sql)
            db.query(sql, function (err, result) {
                if (err) reject(err)
                resolve(result);
            })
        });
    },

    updateProduct: function (id, name) {
        return new Promise((resolve, reject) => {
            var sql = `
                    update produkt
                    set navn='${name}'
                    where id = ${id}
                    `;
            console.log(sql)
            db.query(sql, function (err, result) {
                if (err) reject(err)
                resolve(result);
            })
        });
    }
}