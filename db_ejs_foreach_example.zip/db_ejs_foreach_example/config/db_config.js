
module.exports = function (app) {

	const mysql = require('mysql2');

	const connection = mysql.createConnection({
		host: 'localhost',
		user: 'root',
		password: '',
		database: 'db_ejs_foreach_example'
	});

	connection.connect();

	global.db = connection;
};