module.exports = {

	getOne: async (categoryID) => {
		return new Promise ((resolve, reject) => {

			db.query (`
				
				SELECT
					id,
					name
				FROM category
				WHERE id = ?
				
				`, [categoryID], (error, result) => {

					if (error) {
						console.log (error);
						reject (error);
					} else {
						resolve (result[0]);
					}
				}
			);
		});
	},

	// ================================================================

	getAll: async () => {
		return new Promise ((resolve, reject) => {

			db.query (`
				
				SELECT
					id,
					name
				FROM category
				
				`, (error, result) => {

					if (error) {
						console.log (error);
						reject (error);
					} else {
						resolve (result);
					}
				}
			);
		});
	},
}