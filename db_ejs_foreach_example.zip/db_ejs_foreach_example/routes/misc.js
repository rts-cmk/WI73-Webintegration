
const Category = require ("../services/category");

module.exports = (app) => {

	// ================================================================

	app.get ('/', async (req, res) => {

		res.render ('pages/frontpage');
	});

	// ================================================================

	app.get ('/01_display_as_links', async (req, res) => {

		let allCategories = await Category.getAll ();
		
		res.render ('pages/01_display_as_links', {
			"allCategories": allCategories
		});
	});

	// ================================================================

	app.get ('/02_display_as_dropdown', async (req, res) => {

		let allCategories = await Category.getAll ();

		res.render ('pages/02_display_as_dropdown', {
			"allCategories": allCategories
		});
	});

	// ================================================================

	app.get ('/03_specific_category/:categoryID', async (req, res) => {

		let categoryID = req.params.categoryID;
		let oneCategory = await Category.getOne (categoryID);

		res.render ('pages/03_specific_category', {
			"oneCategory": oneCategory
		});
	});

	// ================================================================

}

