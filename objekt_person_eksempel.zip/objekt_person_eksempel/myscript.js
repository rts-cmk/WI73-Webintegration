
// OBS: Da jeg holdt oplæg, lavede jeg bare console.log INDEN I funktionerne,
// bare for at holde det simpelt.

// Nu returnerer jeg beskederne i stedet og så må udviklerne selv bestemme,
// hvad der skal ske med beskederne.

let person = function () {

	return {
		fornavn: "Ukendt",
		efternavn: "Ukendtsen",

		hils: function () {
			return `Hej med dig`;
		},

		hilsPaaNavn: function (navn) {
			return `Hej med dig, ${navn}`;
		},

		praesenter: function () {
			return `Hej, jeg hedder ${this.fornavn} ${this.efternavn}`; // Husk at skrive "this" foran objektets properties
		}
	}
}

// Introducér javascript for variablen "besked", så jeg kan bruge variablen flere længere nede.
let besked;

let p1 = person(); // Opretter person 1
p1.fornavn = "Mickey";
p1.efternavn = "Mouse";

let p2 = person(); // Opretter person 2
p2.fornavn = "Anders";
p2.efternavn = "And";

// -------------------------------------

// Person 1 præsenterer sig selv
besked = p1.praesenter();
console.log(besked);

// Person 1 præsenterer sig selv
besked = p1.praesenter();
console.log(besked);

// -------------------------------------

// Person 1 hilser
besked = p1.hilsPaaNavn("Anders");
console.log(besked);

// Person 2 hilser
besked = p2.hilsPaaNavn("Mickey");
console.log(besked);

// -------------------------------------

// Øvelse:

// Kan du lave en funktion inden i objektet,
// som hedder hilsPaaPerson
// og som tager imod et objekt af typen person.
// Når funktionen hilser, skal den bruge personens fornavn og efternavn.

// Eksempel på kaldet:
// p1.hilsPaaPerson(p2) // <--- Læg mærke til, at jeg ikke har skrevet "Anders And" her

// Hvordan skal definitionen se ud?