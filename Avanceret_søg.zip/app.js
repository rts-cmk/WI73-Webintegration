// node-modules
const express = require('express');
const path = require('path');
const bodyparser = require('body-parser');
const morgan = require('morgan');

const app=express();

// app.use

app.use(bodyparser.json());
app.use(bodyparser.urlencoded({ extended: true }));

app.use(express.static(path.join(__dirname, 'public')));
app.use(morgan('dev'));

// app.set
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');

require('./routes/index')(app);
require('./routes/produkt')(app);

const port = 3333;
console.log(`Serveren kører på http://localhost:${port}`);
app.listen(port);