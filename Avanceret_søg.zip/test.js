const produkt = require('./services/db/produkt');

// function alle() {
//     produkt.getAll()
//         .then((result) => {
//             console.log(result)
//             console.log('===================================');
//         })
//         .catch((err) => { console.log(err) });
// }
// alle();

// async function hentAlle() {
//     let produkter = await produkt.getAll();
//     console.log(produkter)
// }
// hentAlle();

async function search(txt, kategori, pris) {
    let produkter = await produkt.search(txt, kategori, pris);
    console.log(produkter)
};
search('', [1], '');


