let produkt = require('../services/db/produkt')

module.exports = (app) => {

    app.post('/search', async (req, res) => {
        //console.log('body: ', req.body)
        let txt = req.body.txt;
        let kategori = req.body.kategori;
        let pris = req.body.pris;
        let produkter = await produkt.search(txt, kategori, pris);
        //console.log('route produkter: ', produkter)
        res.render('produkt', { "produkter": produkter });
    });

    app.get('/produkter', ((req, res) => {
        res.render('produkt');
    }))

    app.post('/insert', async (req, res) => {
        try {
            produkt.insertProduct(null, req.body.navn, req.body.pris, req.body.kategori);
            // færdiggøres med json tilbagemelding
            res.render('produkt');
        } catch (e) {

        }
    })

    app.post('/update/:id', async (req, res) => {
        console.log('body', req.body)
        produkt.updateProduct(req.params.id, req.body.navn);
        // færdiggøres med json tilbagemelding
        res.redirect('/produkter');
    })

    app.get('/countName/:name', async (req, res) => {
        let count = await produkt.getCount(req.params.name)
        console.log('antal: ', count[0])
        res.send(count[0]);
    })

}