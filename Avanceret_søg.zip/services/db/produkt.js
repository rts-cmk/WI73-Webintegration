const db = require('../../config/database').connect();

module.exports = {

    search: function (txt, kategori = [], pris) {
        txt = txt == '' ? '_' : txt;
        // Herunder én løsning. Kunne med fordel gøre "produkt.fk_kategori in (?) and" dynamisk
        if (kategori.length == 0) {
            for (i = 0; i < 10; i++)kategori.push(i);
        }
        pris = (pris == '' || isNaN(pris))? 1000000 : pris;

        console.log('service: ', 'txt=', txt, 'kategori=', kategori, 'pris=', pris)
        return new Promise((resolve, reject) => {
            let prepare = ['%' + txt + '%', kategori, pris]
            var sql = `
                select 
                produkt.navn,
                produkt.pris
                from produkt
                where
                produkt.navn like ? and
                produkt.fk_kategori in (?) and
                produkt.pris <= ?
            `;
            db.query(sql, prepare, function (err, result) {
                if (err) reject('fejl');
                resolve(result);
            })
        })
    },

    getAll: function () {
        return new Promise((resolve, reject) => {
            var sql = `
                select 
                produkt.navn,
                produkt.pris
                from produkt 
            `;
            db.query(sql, function (err, result) {
                if (err) reject('fejl');
                resolve(result);
            })
        })
    },

    getCount: function (name) {
        return new Promise((resolve, reject) => {
            var sql = `
                    SELECT COUNT(*) AS antal
                    FROM produkt
                    WHERE produkt.navn = ?
                `;
            db.query(sql, [name], function (err, result) {
                if (err) reject(err)

                resolve(result);
            });

        })
    },

    insertProduct: function (id, navn, pris, kategori) {
        return new Promise((resolve, reject) => {
            var sql = `
                    insert into produkt set 
                    id='${id}',
                    navn='${navn}',
                    pris='${pris}',
                    fk_kategori='${kategori}'
                    `;
            console.log(sql)
            db.query(sql, function (err, result) {
                if (err) reject(err)
                resolve(result);
            })
        });
    },

    updateProduct: function (id, name) {
        return new Promise((resolve, reject) => {
            var sql = `
                    update produkt
                    set navn='${name}'
                    where id = ${id}
                    `;
            console.log(sql)
            db.query(sql, function (err, result) {
                if (err) reject(err)
                resolve(result);
            })
        });
    }
}