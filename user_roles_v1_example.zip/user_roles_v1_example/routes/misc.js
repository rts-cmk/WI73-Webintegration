
const User = require ("../services/user");

module.exports = (app) => {

	// ================================================================

	app.get ('/', async (req, res) => {

		res.render ('pages/frontpage', {
			userSession: req.session.user
		});
	});

	// ================================================================

	app.get ('/login', async (req, res) => {

		// This is used to display all users and their passwords on the login page for TESTING PURPOSES.
		// You should not do this, of course :)

		let DONT_DO_THIS__allUsersAndPasswords = await User.getAll ();

		res.render ('pages/login', {
			userSession: req.session.user,
			
			// Seriously, don't do this...
			DONT_DO_THIS__allUsersAndPasswords: DONT_DO_THIS__allUsersAndPasswords
		});
	});

	// ================================================================

	app.post ('/login', async (req, res) => {

		// This is used to display messages to the user
		let feedback = undefined;
		
		// Collect data from the form
		let username = req.body.username;
		let password = req.body.password;

		let users = await User.getUsersByUsername (username);

		// Check if only ONE user was found with that username
		if (users.length == 1) {

			let user = users[0];

			// Check if the password is correct  (No hash in this example for the sake of simplicity)
			if (user.password == password) {
				
				// Save user data in Session
				req.session.user = {
					"id": user.id,
					"username": user.username,
					"roleID": user.fk_role_id
				};

				if (req.session.user.roleID == 1) {
					res.redirect ("/admin/01_admins_only");
				}

				else

				if (req.session.user.roleID == 2) {
					res.redirect ("/admin/02_moderators_only");
				}

				else
				
				if (req.session.user.roleID == 3) {
					res.redirect ("/admin/03_members_only");
				}
				
				// Return skips the rest of the code (to avoid res.render)
				return;
			}
			else {
				feedback = { message: "Wrong username or password",  type: "error" };
			}

		} else {

			
			// Check if no users were found with that username
			if (users.length == 0) feedback = { message: "Wrong username or password",  type: "error" };

			// Check if 2 or more users were found with that username
			if (users.length >= 2) feedback = { message: "More than one user with that username was found. Contact the admin.",  type: "error" };
		}


		// This is used to display all users and their passwords on the login page for TESTING PURPOSES.
		// You should not do this, of course :)

		let DONT_DO_THIS__allUsersAndPasswords = await User.getAll ();

		res.render ('pages/login', {
			userSession: req.session.user,
			feedback: feedback,
			username: username,

			// Seriously, don't do this...
			DONT_DO_THIS__allUsersAndPasswords: DONT_DO_THIS__allUsersAndPasswords
		});

	});

	// ================================================================

	app.get ('/cheat_login/:username/', async (req, res) => {

		// REMEMBER TO DELETE THIS ROUTE!!!

		let users = await User.getUsersByUsername (req.params.username);
		let user = users[0];
		
		req.session.user = {
			"id": user.id,
			"username": user.username,
			"roleID": user.fk_role_id
		};

		res.redirect ("/admin");
	});

	// ================================================================

	app.get ('/logout', async (req, res) => {

		delete req.session.user;
		res.redirect ("/login");
	});

	// ================================================================

	app.get ('/admin', async (req, res) => {

		if (typeof req.session.user === "undefined") {
			res.redirect ('/login');
			return;
		}

		res.render ('admin/pages/admin_frontpage', {
			userSession: req.session.user
		});
	});

	// ================================================================

	app.get ('/admin/01_admins_only', async (req, res) => {

		if (typeof req.session.user === "undefined" || req.session.user.roleID != 1) {
			res.redirect ('/admin/accessdenied');
			return;
		}

		res.render ('admin/pages/01_admins_only', {
			userSession: req.session.user
		});
	});

	// ================================================================

	app.get ('/admin/02_moderators_only', async (req, res) => {

		if (typeof req.session.user === "undefined" || req.session.user.roleID != 2) {
			res.redirect ('/admin/accessdenied');
			return;
		}

		res.render ('admin/pages/02_moderators_only', {
			userSession: req.session.user
		});
	});

	// ================================================================

	app.get ('/admin/03_members_only', async (req, res) => {

		if (typeof req.session.user === "undefined" || req.session.user.roleID != 3) {
			res.redirect ('/admin/accessdenied');
			return;
		}

		res.render ('admin/pages/03_members_only', {
			userSession: req.session.user
		});
	});

	// ================================================================

	app.get ('/admin/04_mixed_roles', async (req, res) => {

		res.render ('admin/pages/04_mixed_roles', {
			userSession: req.session.user
		});
	});

	// ================================================================

	app.get ('/admin/accessdenied', async (req, res) => {

		res.render ('admin/pages/accessdenied', {
			userSession: req.session.user
		});
	});

	// ================================================================

}

