
module.exports = (app) => {

	const mysql = require ('mysql2');

	const connection = mysql.createConnection ({
		host: 'localhost',
		user: 'root',
		password: '',
		database: 'user_roles_example'
	});

	connection.connect();

	global.db = connection;
};