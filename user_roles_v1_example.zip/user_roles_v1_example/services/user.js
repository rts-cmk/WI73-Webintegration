module.exports = {

	// ================================================================

	getOneByID: async (userID) => {
		return new Promise ((resolve, reject) => {

			db.query (`
				
				SELECT
					user.id,
					user.username,
					user.password,
					user.fk_role_id,
					role.name AS role_name
				FROM user
				INNER JOIN role ON fk_role_id = role.id
				WHERE user.id = ?
				
				`, [userID], (error, result) => {

					if (error) {
						console.log (error);
						reject (error);
					} else {
						resolve (result[0]);
					}
				}
			);
		});
	},

	// ================================================================

	getUsersByUsername: async (username) => {

		return new Promise ((resolve, reject) => {

			db.query (`

				SELECT
					user.id,
					user.username,
					user.password,
					user.fk_role_id,
					role.name AS role_name
				FROM user
				INNER JOIN role ON fk_role_id = role.id
				WHERE username = ?
				
				`, [username], (error, result) => {

					if (error) {
						console.log (error);
						reject (error);
					} else {
						resolve (result);
					}
				}
			);
		});
	},

	// ================================================================

	getAll: async () => {
		return new Promise ((resolve, reject) => {

			db.query (`
				
				SELECT
					user.id,
					user.username,
					user.password,
					user.fk_role_id,
					role.name AS role_name
				FROM user
				INNER JOIN role ON fk_role_id = role.id
				
				`, (error, result) => {

					if (error) {
						console.log (error);
						reject (error);
					} else {
						resolve (result);
					}
				}
			);
		});
	},

	// ================================================================

	getAllByRoleID: async (roleID) => {
		return new Promise ((resolve, reject) => {

			db.query (`
				
				SELECT
					user.id,
					user.username,
					user.password,
					user.fk_role_id,
					role.name AS role_name
				FROM user
				INNER JOIN role ON fk_role_id = role.id
				WHERE fk_role_id = ?
				
				`, [roleID], (error, result) => {

					if (error) {
						console.log (error);
						reject (error);
					} else {
						resolve (result);
					}
				}
			);
		});
	},

	// ================================================================

}