module.exports= function(app){
    app.get('/', (req, res)=>{
        res.render('pages/index'); // Hent evt. billederne til visning på siden
    });
}