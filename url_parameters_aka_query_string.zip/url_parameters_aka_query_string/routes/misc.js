
module.exports = (app) => {

	// ================================================================

	app.get ('/', async (req, res) => {

		res.render ('pages/frontpage');
	});

	// ================================================================

	app.get ('/01_form', async (req, res) => {

		// ----------------------------------------------------------------
		// Get data from the Query String (URL)

		let price = req.query.price;
		let amount = req.query.amount;


		// ----------------------------------------------------------------
		// Check if the data has been received and react accordingly

		if (typeof price !== 'undefined' && price != "") {
			console.log ("price received");
		} else {
			console.log ("price missing");
		}

		if (typeof amount !== 'undefined' && amount != "") {
			console.log ("amount received");
		} else {
			console.log ("amount missing");
		}

		
		// ----------------------------------------------------------------
		// Render
		
		res.render ('pages/01_form', {
			"price": price,
			"amount": amount
		});
	});

	// ================================================================

}

