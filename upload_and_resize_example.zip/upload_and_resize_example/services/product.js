module.exports = {

	// ================================================================

	insert: async (name, price) => {
		return new Promise ((resolve, reject) => {

			db.query (`
				
				INSERT INTO product
				SET
					name = ?,
					price = ?
				
				`, [name, price], (error, result) => {

					if (error) {
						console.log (error);
						reject (error);
					} else {
						resolve (result);
					}
				}
			);
		});
	},

	// ================================================================

	insertImage: async (filename, fk_product_id) => {
		return new Promise ((resolve, reject) => {

			db.query (`
				
				INSERT INTO product_image
				SET
					filename = ?,
					fk_product_id = ?
				
				`, [filename, fk_product_id], (error, result) => {

					if (error) {
						console.log (error);
						reject (error);
					} else {
						resolve (result);
					}
				}
			);
		});
	},

	// ================================================================

}