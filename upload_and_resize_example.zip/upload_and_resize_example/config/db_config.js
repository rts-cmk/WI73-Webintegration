
module.exports = (app) => {

	const mysql = require ('mysql2');

	const connection = mysql.createConnection ({
		host: 'localhost',
		user: 'root',
		password: '',
		database: 'upload_and_resize_example'
	});

	connection.connect();

	global.db = connection;
};