
console.log ("\n================================================\n");


// ================================================================
// :: Dependencies

const express    = require ('express');
const path       = require ('path');
const bodyParser = require ('body-parser');
const morgan     = require ('morgan');
const app        = express ();

require ("./config/db_config") (app);



// ================================================================
// :: Configuration

app.set ('view engine', 'ejs');
app.use ('/', express.static (path.join (__dirname, 'public')));
app.use (bodyParser.json ());
app.use (bodyParser.urlencoded ({ extended: false }));
app.use (morgan ("dev"));



// ================================================================
// :: Routes

require ("./routes/misc") (app);



// ================================================================
// :: Server Listen

const port = 3000;
app.listen (port, () => console.log (`Server running - http://localhost:${port}`))
