
const Product     = require ('../services/product');

// Formidable handles form data (regular fields + uploaded files, but not resizing)
const formidable  = require ('formidable');

// Sharp handles image resizing.  Documentation: http://sharp.dimens.io/en/stable/
const sharp       = require ('sharp');

module.exports = (app) => {

	// ================================================================

	app.get ('/', async (req, res) => {

		res.render ('pages/frontpage');
	});

	// ================================================================

	app.get ('/admin', async (req, res) => {

		res.render ('admin/pages/admin_frontpage');
	});

	// ================================================================

	app.get ('/admin/product/insert', async (req, res) => {

		res.render ('admin/pages/admin_product_insert');
	});

	// ================================================================

	app.post ('/admin/product/insert', async (req, res) => {

		// Enables/Disables debugging (only within this route)
		let debug = true;

		if (debug) console.log ("\n---------\n");

		// Timestamp example: 1537738117714  (Milliseconds since 1970. Used to generate unique image filenames)
		let timestamp = Date.now();

		let form = new formidable.IncomingForm ();

		// Allows multiple files
		form.multiples = true;

		form.parse (req, function (err, fields, files) {

			// When using formidable, req.body is not directly available.
			// This copies the form data from formidable to req.body
			req.body = fields;
		});

		form.on ("end", async () => {

			// ----------------------------------------------------------------
			// Collect data from the form

			let name = req.body.name;
			let price = req.body.price;

			if (debug) console.log ("req.body: ", req.body);

			// ----------------------------------------------------------------
			// Insert product into the database

			let insertProduct = await Product.insert (name, price);
			let productID = insertProduct.insertId;
			if (debug) console.log ("Inserted Product ID: ", productID);

			// ----------------------------------------------------------------
			// Image upload and resize

			let allFiles = form.openedFiles;

			let destinationFile = ""; // Do NOT change this here.
			let imageFolder = "public/images/products/";

			for (let i = 0; i < allFiles.length; i++) {
				let file = allFiles[i];
				
				let uniqueFilename = `${timestamp}_${file.name}`; // Example: 1537738117714_monkey.jpg
				let sourceFile = file.path;  // Example: C:\Users\ChuckNorris\AppData\Local\Temp\upload_40536f848dded4c0c81e2401713bca4c

				if (debug) console.log ("Unique Filename: ", uniqueFilename);
				
				// Large Image
				destinationFile = imageFolder + "large/" + uniqueFilename;
				await sharp (sourceFile)  .resize(400, 300)  .max()  .toFile(destinationFile);
				
				// Small Image
				destinationFile = imageFolder + "small/" + uniqueFilename;
				await sharp (sourceFile)  .resize(80, 60)  .max()  .toFile(destinationFile);

				// Insert image into a separate table in the database
				if (debug) console.log ("DB Insert image: ",  uniqueFilename,  "\n---");
				await Product.insertImage (uniqueFilename, productID);
			};

			// ----------------------------------------------------------------
			
			// TODO: Redirect
			// Here you should probably redirect to another admin page,
			// for example a product list.

			// res.redirect("/admin/products");  // The route "/admin/products" is NOT included in the example
			// return
		});

		// This is a temporary solution. It's used only while testing. Delete this line once you've added a redirect above.
		res.send ("Done. Check the <strong>server log</strong> and the <strong>database</strong>");
	});

	// ================================================================

}

